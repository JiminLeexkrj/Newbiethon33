import {
  createInitialMockTrip,
  createTrafficChangedMockTrip,
  MOCK_CURRENT_LOCATION,
} from "@/data/mock-trip";
import type {
  CurrentLocation,
  StartTripRequest,
  TripSnapshot,
  UserPreferences,
} from "@/types/trip";

/**
 * 개발자 2 연결 지점: 브라우저 위치 또는 위치 API 구현체가 이 계약을 구현합니다.
 */
export interface LocationProvider {
  getCurrentLocation(): Promise<CurrentLocation>;
}

/**
 * 개발자 2 연결 지점: 지도/대중교통 경로 API 구현체가 이 계약을 구현합니다.
 * 백엔드가 경로 API를 감싸는 경우 TripService 내부에서 사용하면 됩니다.
 */
export interface RouteProvider {
  searchRoutes(request: StartTripRequest): Promise<TripSnapshot["routes"]>;
}

/**
 * 개발자 3 연결 지점: 정시 도착 계산 및 백엔드 API 응답을 이 계약에 맞춥니다.
 */
export interface TripService {
  getCurrentLocation(): Promise<CurrentLocation>;
  startTrip(request: StartTripRequest): Promise<TripSnapshot>;
  getTripSnapshot(tripId: string): Promise<TripSnapshot>;
  savePreferences(
    tripId: string,
    preferences: UserPreferences,
  ): Promise<void>;
  simulateTrafficEvent(tripId: string): Promise<TripSnapshot>;
}

const wait = (milliseconds: number) =>
  new Promise((resolve) => window.setTimeout(resolve, milliseconds));

class MockTripService implements TripService {
  private trips = new Map<string, TripSnapshot>();

  async getCurrentLocation() {
    await wait(450);
    return MOCK_CURRENT_LOCATION;
  }

  async startTrip(request: StartTripRequest) {
    await wait(700);
    const trip = createInitialMockTrip(request);
    this.trips.set(trip.tripId, trip);
    return trip;
  }

  async getTripSnapshot(tripId: string) {
    await wait(250);
    const trip = this.trips.get(tripId);
    if (!trip) throw new Error("이동 정보를 찾을 수 없습니다.");
    return trip;
  }

  async savePreferences(
    tripId: string,
    _preferences: UserPreferences,
  ) {
    await wait(350);
    if (!this.trips.has(tripId)) {
      throw new Error("이동 정보를 찾을 수 없습니다.");
    }
  }

  async simulateTrafficEvent(tripId: string) {
    await wait(900);
    const current = this.trips.get(tripId);
    if (!current) throw new Error("이동 정보를 찾을 수 없습니다.");

    const changed = createTrafficChangedMockTrip(current);
    this.trips.set(tripId, changed);
    return changed;
  }
}

// 실제 API 연결 시 이 한 줄의 구현체만 교체해도 UI는 그대로 유지됩니다.
export const tripService: TripService = new MockTripService();

